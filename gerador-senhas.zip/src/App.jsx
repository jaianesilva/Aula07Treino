import { useState } from "react";
import "./App.css";

function App() {
  const [senha, setSenha] = useState("");
  const [copiado, setCopiado] = useState(false);

  function gerarSenha() {
    const caracteres =
      "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*?";
    let novaSenha = "";

    for (let i = 0; i < 12; i++) {
      const randomIndex = Math.floor(Math.random() * caracteres.length);
      novaSenha += caracteres[randomIndex];
    }

    setSenha(novaSenha);
    setCopiado(false);
  }

  function copiarSenha() {
    navigator.clipboard.writeText(senha);
    setCopiado(true);
  }

  return (
    <div className="container">
      <h1>Gerador de senhas</h1>

      <div className="buttons">
        <button className="gerar" onClick={gerarSenha}>
          Gerar!
        </button>

        <button className="copiar" onClick={copiarSenha}>
          {copiado ? "Copiado!" : "Copiar"}
        </button>
      </div>

      {senha && <p className="senha">{senha}</p>}
    </div>
  );
}

export default App;